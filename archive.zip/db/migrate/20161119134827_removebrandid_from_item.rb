class RemovebrandidFromItem < ActiveRecord::Migration
  def change
  end
end
