require 'test_helper'

class ItemImgTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
