class ItemBrand < ActiveRecord::Base
  has_many :items
end
