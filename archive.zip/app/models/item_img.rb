class ItemImg < ActiveRecord::Base
  belongs_to :items
end
